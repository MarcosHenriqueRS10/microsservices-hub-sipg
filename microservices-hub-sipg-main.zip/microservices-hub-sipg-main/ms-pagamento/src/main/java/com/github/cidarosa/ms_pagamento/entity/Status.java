package com.github.cidarosa.ms_pagamento.entity;

public enum Status {

    CRIADO,
    CONFIRMADO,
    CANCELADO
}
